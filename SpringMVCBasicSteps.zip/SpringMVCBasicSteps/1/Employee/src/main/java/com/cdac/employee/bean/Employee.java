package com.cdac.employee.bean;

public class Employee {

}
