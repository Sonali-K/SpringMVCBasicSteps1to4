package com.cdac.employee.dao;

public interface IEmployeeDao {

}
