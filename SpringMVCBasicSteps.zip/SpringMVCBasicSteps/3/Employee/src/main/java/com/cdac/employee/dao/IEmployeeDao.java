package com.cdac.employee.dao;

import com.cdac.employee.bean.Employee;

public interface IEmployeeDao {
	public int save(Employee e);

}
