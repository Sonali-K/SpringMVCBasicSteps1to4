package com.cdac.employee.service;

import com.cdac.employee.bean.Employee;

public interface IEmployeeService {
	public int save(Employee e);
}
